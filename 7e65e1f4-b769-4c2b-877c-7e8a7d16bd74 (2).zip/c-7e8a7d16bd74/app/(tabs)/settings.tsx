
import Toast, { ToastType } from '@/components/Toast';
import { Stack, router } from 'expo-router';
import { useApp } from '@/contexts/AppContext';
import { Gender, Units } from '@/types';
import { colors, commonStyles, buttonStyles } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput, Alert, Switch, ActivityIndicator } from 'react-native';
import PremiumModal from '@/components/PremiumModal';
import React, { useState } from 'react';

const GENDERS: Gender[] = ['Male', 'Female', 'Other'];
const UNITS: Units[] = ['mg', 'mcg', 'ml', 'IU'];

export default function SettingsScreen() {
  const { 
    user, 
    setUser, 
    isPremium, 
    logout,
    refreshSubscriptionStatus,
  } = useApp();
  const [age, setAge] = useState(user?.age?.toString() || '');
  const [gender, setGender] = useState<Gender>(user?.gender || 'Male');
  const [goals, setGoals] = useState(user?.goals || '');
  const [units, setUnits] = useState<Units>(user?.units || 'mg');
  const [darkMode, setDarkMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<ToastType>('success');

  const showToast = (message: string, type: ToastType = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setToastVisible(true);
  };

  const handleSaveProfile = async () => {
    if (!age || isNaN(parseInt(age))) {
      showToast('Please enter a valid age', 'error');
      return;
    }

    setSaving(true);
    try {
      const updatedUser = {
        ...user,
        age: parseInt(age),
        gender,
        goals,
        units,
        isPremium: user?.isPremium || false,
      };
      setUser(updatedUser);
      showToast('Profile updated successfully', 'success');
    } catch (error) {
      console.error('Error saving profile:', error);
      showToast('Failed to save profile', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleUpgradePremium = () => {
    setShowPremiumModal(true);
  };

  const handleExportData = () => {
    Alert.alert(
      'Export Data',
      'Export functionality coming soon. You will be able to export your data as PDF or CSV.',
      [{ text: 'OK' }]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'Are you sure you want to delete your account? This action cannot be undone and all your data will be permanently deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            await logout();
            router.replace('/onboarding');
          },
        },
      ]
    );
  };

  const handlePurchaseSuccess = async () => {
    // Refresh subscription status after successful purchase
    await refreshSubscriptionStatus();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Settings',
          headerShown: true,
        }}
      />
      <ScrollView style={styles.container}>
        {/* Profile Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Profile</Text>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Age</Text>
            <TextInput
              style={styles.input}
              value={age}
              onChangeText={setAge}
              placeholder="Enter your age"
              placeholderTextColor={colors.textSecondary}
              keyboardType="number-pad"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Gender</Text>
            <View style={styles.segmentedControl}>
              {GENDERS.map((g) => (
                <Pressable
                  key={g}
                  style={[
                    styles.segmentButton,
                    gender === g && styles.segmentButtonActive,
                  ]}
                  onPress={() => setGender(g)}
                >
                  <Text
                    style={[
                      styles.segmentButtonText,
                      gender === g && styles.segmentButtonTextActive,
                    ]}
                  >
                    {g}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Goals</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={goals}
              onChangeText={setGoals}
              placeholder="Enter your health goals"
              placeholderTextColor={colors.textSecondary}
              multiline
              numberOfLines={4}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Preferred Units</Text>
            <View style={styles.segmentedControl}>
              {UNITS.map((u) => (
                <Pressable
                  key={u}
                  style={[
                    styles.segmentButton,
                    units === u && styles.segmentButtonActive,
                  ]}
                  onPress={() => setUnits(u)}
                >
                  <Text
                    style={[
                      styles.segmentButtonText,
                      units === u && styles.segmentButtonTextActive,
                    ]}
                  >
                    {u}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          <Pressable
            style={[buttonStyles.primary, saving && styles.buttonDisabled]}
            onPress={handleSaveProfile}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={buttonStyles.buttonText}>Save Profile</Text>
            )}
          </Pressable>
        </View>

        {/* Premium Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Premium</Text>

          <View style={styles.premiumCard}>
            <View style={styles.premiumHeader}>
              <IconSymbol
                name={isPremium ? 'checkmark.circle.fill' : 'star.fill'}
                size={32}
                color={isPremium ? colors.success : colors.highlight}
              />
              <View style={styles.premiumInfo}>
                <Text style={styles.premiumStatus}>
                  {isPremium ? 'Premium Active' : 'Free Plan'}
                </Text>
                <Text style={styles.premiumDescription}>
                  {isPremium
                    ? 'Unlimited tracking & features'
                    : 'Limited to 1 product'}
                </Text>
              </View>
            </View>

            {!isPremium && (
              <Pressable style={buttonStyles.primary} onPress={handleUpgradePremium}>
                <IconSymbol name="star.fill" size={20} color="#fff" />
                <Text style={buttonStyles.buttonText}>Upgrade to Premium</Text>
              </Pressable>
            )}
          </View>
        </View>

        {/* App Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>App Settings</Text>

          <View style={styles.settingRow}>
            <View style={styles.settingInfo}>
              <Text style={styles.settingLabel}>Dark Mode</Text>
              <Text style={styles.settingDescription}>Coming soon</Text>
            </View>
            <Switch
              value={darkMode}
              onValueChange={setDarkMode}
              disabled={true}
            />
          </View>
        </View>

        {/* Data Management */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Data Management</Text>

          <Pressable style={buttonStyles.secondary} onPress={handleExportData}>
            <IconSymbol name="square.and.arrow.up" size={20} color={colors.primary} />
            <Text style={buttonStyles.buttonTextSecondary}>Export Data</Text>
          </Pressable>

          <Pressable
            style={[buttonStyles.secondary, styles.deleteButton]}
            onPress={handleDeleteAccount}
          >
            <IconSymbol name="trash" size={20} color={colors.alert} />
            <Text style={[buttonStyles.buttonTextSecondary, styles.deleteButtonText]}>
              Delete Account
            </Text>
          </Pressable>
        </View>

        {/* App Info */}
        <View style={styles.section}>
          <Text style={styles.appVersion}>BioHacker Nexus v1.0.0</Text>
          <Text style={styles.appDisclaimer}>
            Not medical advice. Consult your healthcare provider.
          </Text>
        </View>
      </ScrollView>

      <Toast
        visible={toastVisible}
        message={toastMessage}
        type={toastType}
        onHide={() => setToastVisible(false)}
      />

      <PremiumModal
        visible={showPremiumModal}
        onClose={() => setShowPremiumModal(false)}
        onPurchaseSuccess={handlePurchaseSuccess}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  section: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 16,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    marginBottom: 8,
  },
  input: {
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: colors.text,
    borderWidth: 1,
    borderColor: colors.border,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  segmentedControl: {
    flexDirection: 'row',
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 4,
  },
  segmentButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
    borderRadius: 6,
  },
  segmentButtonActive: {
    backgroundColor: colors.primary,
  },
  segmentButtonText: {
    fontSize: 14,
    color: colors.textSecondary,
  },
  segmentButtonTextActive: {
    color: '#fff',
    fontWeight: '600',
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  premiumCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
  },
  premiumHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  premiumInfo: {
    marginLeft: 12,
    flex: 1,
  },
  premiumStatus: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  premiumDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 2,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    borderRadius: 8,
    padding: 16,
  },
  settingInfo: {
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  settingDescription: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  deleteButton: {
    marginTop: 12,
    borderColor: colors.alert,
  },
  deleteButtonText: {
    color: colors.alert,
  },
  appVersion: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginBottom: 8,
  },
  appDisclaimer: {
    fontSize: 12,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 18,
  },
});
