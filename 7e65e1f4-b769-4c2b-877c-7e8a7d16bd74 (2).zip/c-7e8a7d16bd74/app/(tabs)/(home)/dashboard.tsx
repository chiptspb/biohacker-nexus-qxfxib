
import { Stack, router } from 'expo-router';
import { DoseDue, LowStockAlert } from '@/types';
import PremiumModal from '@/components/PremiumModal';
import { useApp } from '@/contexts/AppContext';
import React, { useState, useMemo } from 'react';
import { colors, commonStyles, buttonStyles } from '@/styles/commonStyles';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert, RefreshControl } from 'react-native';
import { parseISO, startOfDay, endOfDay, isWithinInterval, isBefore, getDay, format } from 'date-fns';
import { IconSymbol } from '@/components/IconSymbol';

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function DashboardScreen() {
  const { 
    products, 
    inventory, 
    doseLogs, 
    scheduledDoses, 
    isPremium,
    refreshSubscriptionStatus,
  } = useApp();
  const [refreshing, setRefreshing] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);

  const onRefresh = async () => {
    setRefreshing(true);
    // Simulate data refresh
    await new Promise(resolve => setTimeout(resolve, 1000));
    // Refresh subscription status
    await refreshSubscriptionStatus();
    setRefreshing(false);
  };

  // Calculate doses due today
  const dosesDueToday = useMemo(() => {
    const today = startOfDay(new Date());
    const todayEnd = endOfDay(new Date());

    const dues: DoseDue[] = [];

    // Get scheduled doses for today that haven't been completed
    scheduledDoses.forEach(dose => {
      if (dose.completed) return;

      const doseDate = startOfDay(parseISO(dose.scheduledDate));
      
      if (isWithinInterval(doseDate, { start: today, end: todayEnd })) {
        const product = products.find(p => p.id === dose.productId);
        if (product) {
          dues.push({
            productId: dose.productId,
            productName: dose.productName,
            doseAmount: dose.doseAmount,
            route: dose.route,
            scheduledDate: dose.scheduledDate,
            scheduledDoseId: dose.id,
          });
        }
      }
    });

    console.log('Doses due today:', dues.length);
    return dues;
  }, [scheduledDoses, products]);

  // Calculate low stock alerts
  const lowStockAlerts = useMemo(() => {
    const alerts: LowStockAlert[] = [];

    products.forEach(product => {
      const inv = inventory.find(i => i.productId === product.id);
      if (!inv) return;

      const protocolInfo = getProtocolInfo(product.id);
      if (!protocolInfo) return;

      const { doseAmount, frequency } = protocolInfo;
      
      // Calculate doses per month
      let dosesPerMonth = 0;
      if (frequency.includes('Daily')) dosesPerMonth = 30;
      else if (frequency.includes('Weekly')) dosesPerMonth = 4;
      else if (frequency.includes('Bi-weekly')) dosesPerMonth = 2;
      else if (frequency.includes('Monthly')) dosesPerMonth = 1;

      if (dosesPerMonth === 0) return;

      const totalDoseMgPerMonth = doseAmount * dosesPerMonth;
      const monthsSupply = inv.quantity / totalDoseMgPerMonth;

      if (monthsSupply < 0.5) {
        alerts.push({
          productId: product.id,
          productName: product.name,
          currentQuantity: inv.quantity,
          monthsSupply,
        });
      }
    });

    return alerts;
  }, [products, inventory]);

  const getProtocolInfo = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product || !product.protocol) return null;

    const { doseAmount, frequency, daysOfWeek } = product.protocol;
    
    let freqText = '';
    if (frequency.includes('daily')) freqText = 'Daily';
    else if (frequency.includes('weekly')) {
      if (daysOfWeek && daysOfWeek.length > 0) {
        const dayNames = daysOfWeek.map(d => DAY_NAMES[d]).join(', ');
        freqText = `Weekly (${dayNames})`;
      } else {
        freqText = 'Weekly';
      }
    } else if (frequency.includes('biweekly')) freqText = 'Bi-weekly';
    else if (frequency.includes('monthly')) freqText = 'Monthly';

    return {
      doseAmount,
      frequency: freqText,
    };
  };

  const handleLogDose = () => {
    router.push('/(tabs)/(home)/log-dose');
  };

  const handleUpdateInventory = () => {
    router.push('/(tabs)/inventory');
  };

  const handleManageProtocols = () => {
    router.push('/(tabs)/medications');
  };

  const handleUpgradePremium = () => {
    setShowPremiumModal(true);
  };

  const handleViewCalendar = () => {
    router.push('/(tabs)/(home)/calendar');
  };

  const handlePurchaseSuccess = async () => {
    // Refresh subscription status after successful purchase
    await refreshSubscriptionStatus();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Dashboard',
          headerShown: true,
        }}
      />
      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <IconSymbol name="exclamationmark.triangle.fill" size={16} color={colors.alert} />
          <Text style={styles.disclaimerText}>
            Not medical advice. Consult your healthcare provider.
          </Text>
        </View>

        {/* Doses Due Today */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Doses Due Today</Text>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{dosesDueToday.length}</Text>
            </View>
          </View>

          {dosesDueToday.length === 0 ? (
            <View style={styles.emptyState}>
              <IconSymbol name="checkmark.circle.fill" size={48} color={colors.success} />
              <Text style={styles.emptyStateText}>All caught up!</Text>
              <Text style={styles.emptyStateSubtext}>No doses due today</Text>
            </View>
          ) : (
            <View style={styles.dosesList}>
              {dosesDueToday.map((dose, index) => (
                <View key={index} style={styles.doseItem}>
                  <View style={styles.doseIcon}>
                    <IconSymbol name="pills.fill" size={24} color={colors.primary} />
                  </View>
                  <View style={styles.doseInfo}>
                    <Text style={styles.doseName}>{dose.productName}</Text>
                    <Text style={styles.doseDetails}>
                      {dose.doseAmount} mg • {dose.route}
                    </Text>
                  </View>
                  <IconSymbol name="chevron.right" size={20} color={colors.textSecondary} />
                </View>
              ))}
            </View>
          )}

          <Pressable style={buttonStyles.primary} onPress={handleLogDose}>
            <IconSymbol name="plus.circle.fill" size={20} color="#fff" />
            <Text style={buttonStyles.buttonText}>Log Dose</Text>
          </Pressable>
        </View>

        {/* Low Stock Alerts */}
        {lowStockAlerts.length > 0 && (
          <View style={[styles.card, styles.alertCard]}>
            <View style={styles.cardHeader}>
              <IconSymbol name="exclamationmark.circle.fill" size={24} color={colors.alert} />
              <Text style={[styles.cardTitle, styles.alertTitle]}>Low Stock Alerts</Text>
            </View>

            <View style={styles.alertsList}>
              {lowStockAlerts.map((alert, index) => (
                <View key={index} style={styles.alertItem}>
                  <View style={styles.alertInfo}>
                    <Text style={styles.alertName}>{alert.productName}</Text>
                    <Text style={styles.alertDetails}>
                      {alert.currentQuantity.toFixed(1)} mg remaining
                      {' • '}
                      {alert.monthsSupply < 0.1 ? 'Critical' : `${(alert.monthsSupply * 30).toFixed(0)} days`}
                    </Text>
                  </View>
                </View>
              ))}
            </View>

            <Pressable style={[buttonStyles.secondary, styles.alertButton]} onPress={handleUpdateInventory}>
              <Text style={buttonStyles.buttonTextSecondary}>Update Inventory</Text>
            </Pressable>
          </View>
        )}

        {/* Summary Card */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Summary</Text>
          
          <View style={styles.summaryGrid}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{products.length}</Text>
              <Text style={styles.summaryLabel}>
                {isPremium ? 'Products' : 'Product (Free)'}
              </Text>
            </View>

            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{doseLogs.length}</Text>
              <Text style={styles.summaryLabel}>Total Doses</Text>
            </View>

            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{inventory.length}</Text>
              <Text style={styles.summaryLabel}>In Stock</Text>
            </View>
          </View>

          <Pressable style={buttonStyles.secondary} onPress={handleManageProtocols}>
            <Text style={buttonStyles.buttonTextSecondary}>Manage Protocols</Text>
          </Pressable>
        </View>

        {/* Dose Calendar */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Dose Calendar</Text>
            <IconSymbol name="calendar" size={24} color={colors.primary} />
          </View>
          
          <Text style={styles.cardDescription}>
            View your scheduled doses and track your protocol adherence
          </Text>

          <Pressable style={buttonStyles.secondary} onPress={handleViewCalendar}>
            <IconSymbol name="calendar" size={20} color={colors.primary} />
            <Text style={buttonStyles.buttonTextSecondary}>View Calendar</Text>
          </Pressable>
        </View>

        {/* Premium Upgrade Card */}
        {!isPremium && (
          <View style={[styles.card, styles.premiumCard]}>
            <View style={styles.premiumHeader}>
              <IconSymbol name="star.fill" size={48} color={colors.highlight} />
              <Text style={styles.premiumTitle}>Upgrade to Premium</Text>
              <Text style={styles.premiumSubtitle}>Unlock unlimited tracking</Text>
            </View>

            <View style={styles.premiumFeatures}>
              <View style={styles.premiumFeature}>
                <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                <Text style={styles.premiumFeatureText}>Unlimited medications</Text>
              </View>
              <View style={styles.premiumFeature}>
                <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                <Text style={styles.premiumFeatureText}>Advanced tracking</Text>
              </View>
              <View style={styles.premiumFeature}>
                <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                <Text style={styles.premiumFeatureText}>Export reports</Text>
              </View>
            </View>

            <View style={styles.premiumPricing}>
              <Text style={styles.premiumPrice}>Starting at $2.99/month</Text>
            </View>

            <Pressable style={[buttonStyles.primary, styles.premiumButton]} onPress={handleUpgradePremium}>
              <IconSymbol name="star.fill" size={20} color="#fff" />
              <Text style={buttonStyles.buttonText}>Upgrade Now</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>

      <PremiumModal
        visible={showPremiumModal}
        onClose={() => setShowPremiumModal(false)}
        onPurchaseSuccess={handlePurchaseSuccess}
      />
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  disclaimer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: 12,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: colors.alert,
  },
  disclaimerText: {
    fontSize: 12,
    color: colors.text,
    marginLeft: 8,
    flex: 1,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  cardDescription: {
    fontSize: 14,
    color: colors.textSecondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  badge: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 4,
    minWidth: 32,
    alignItems: 'center',
  },
  badgeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 12,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  dosesList: {
    marginBottom: 16,
  },
  doseItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  doseIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  doseInfo: {
    flex: 1,
  },
  doseName: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  doseDetails: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 2,
  },
  alertCard: {
    borderLeftWidth: 4,
    borderLeftColor: colors.alert,
  },
  alertTitle: {
    color: colors.alert,
    marginLeft: 8,
  },
  alertsList: {
    marginBottom: 16,
  },
  alertItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  alertInfo: {
    flex: 1,
  },
  alertName: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  alertDetails: {
    fontSize: 14,
    color: colors.alert,
    marginTop: 2,
  },
  alertButton: {
    backgroundColor: colors.alert,
  },
  summaryGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 16,
  },
  summaryItem: {
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 32,
    fontWeight: '700',
    color: colors.primary,
  },
  summaryLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
    textAlign: 'center',
  },
  premiumCard: {
    backgroundColor: colors.card,
    borderWidth: 2,
    borderColor: colors.highlight,
    marginBottom: 24,
  },
  premiumHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  premiumTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: colors.text,
    marginTop: 12,
  },
  premiumSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  premiumFeatures: {
    marginBottom: 20,
  },
  premiumFeature: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  premiumFeatureText: {
    fontSize: 16,
    color: colors.text,
    marginLeft: 12,
  },
  premiumPricing: {
    alignItems: 'center',
    marginBottom: 16,
  },
  premiumPrice: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.primary,
  },
  premiumButton: {
    backgroundColor: colors.highlight,
  },
});
