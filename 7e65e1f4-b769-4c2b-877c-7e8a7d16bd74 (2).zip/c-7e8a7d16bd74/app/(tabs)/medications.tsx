
import Toast, { ToastType } from '@/components/Toast';
import { Stack, router } from 'expo-router';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert, Modal, ActivityIndicator } from 'react-native';
import PremiumModal from '@/components/PremiumModal';
import { useApp } from '@/contexts/AppContext';
import { colors, commonStyles, buttonStyles } from '@/styles/commonStyles';
import { IconSymbol } from '@/components/IconSymbol';
import React, { useState } from 'react';

export default function MedicationsScreen() {
  const { 
    products, 
    doseLogs, 
    deleteProduct, 
    canAddProduct, 
    isPremium,
    refreshSubscriptionStatus,
  } = useApp();
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<ToastType>('success');

  const showToast = (message: string, type: ToastType = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setToastVisible(true);
  };

  const handleAddProduct = () => {
    if (!canAddProduct()) {
      setShowPremiumModal(true);
      return;
    }
    router.push('/(tabs)/add-product');
  };

  const handleViewProduct = (productId: string) => {
    router.push({
      pathname: '/(tabs)/product-details',
      params: { productId },
    });
  };

  const handleDeleteProduct = (productId: string, productName: string) => {
    Alert.alert(
      'Delete Product',
      `Are you sure you want to delete "${productName}"? This will remove all associated data including dose logs and inventory.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => confirmDelete(productId, productName),
        },
      ]
    );
  };

  const confirmDelete = (productId: string, productName: string) => {
    deleteProduct(productId);
    showToast(`${productName} deleted successfully`, 'success');
  };

  const getProductStats = (productId: string) => {
    const logs = doseLogs.filter(log => log.productId === productId);
    return {
      totalDoses: logs.length,
      lastDose: logs.length > 0 ? logs[logs.length - 1].timestamp : null,
    };
  };

  const handleUpgradePremium = () => {
    setShowPremiumModal(true);
  };

  const handlePurchaseSuccess = async () => {
    // Refresh subscription status after successful purchase
    await refreshSubscriptionStatus();
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: 'Medications',
          headerShown: true,
        }}
      />
      <View style={styles.container}>
        {/* Disclaimer */}
        <View style={styles.disclaimer}>
          <IconSymbol name="exclamationmark.triangle.fill" size={16} color={colors.alert} />
          <Text style={styles.disclaimerText}>
            Not medical advice. Consult your healthcare provider.
          </Text>
        </View>

        <ScrollView style={styles.content}>
          {products.length === 0 ? (
            <View style={styles.emptyState}>
              <IconSymbol name="pills.fill" size={64} color={colors.textSecondary} />
              <Text style={styles.emptyStateTitle}>No Medications Yet</Text>
              <Text style={styles.emptyStateText}>
                Add your first medication to start tracking
              </Text>
            </View>
          ) : (
            <View style={styles.productsList}>
              {products.map((product) => {
                const stats = getProductStats(product.id);
                return (
                  <Pressable
                    key={product.id}
                    style={styles.productCard}
                    onPress={() => handleViewProduct(product.id)}
                  >
                    <View style={styles.productHeader}>
                      <View style={styles.productIcon}>
                        <IconSymbol name="pills.fill" size={24} color={colors.primary} />
                      </View>
                      <View style={styles.productInfo}>
                        <Text style={styles.productName}>{product.name}</Text>
                        {product.protocol && (
                          <Text style={styles.productProtocol}>
                            {product.protocol.doseAmount} {product.protocol.units} • {product.protocol.frequency.join(', ')}
                          </Text>
                        )}
                        <Text style={styles.productStats}>
                          {stats.totalDoses} doses logged
                        </Text>
                      </View>
                      <Pressable
                        style={styles.deleteButton}
                        onPress={() => handleDeleteProduct(product.id, product.name)}
                      >
                        <IconSymbol name="trash" size={20} color={colors.alert} />
                      </Pressable>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          )}

          {/* Premium Status */}
          {!isPremium && (
            <View style={styles.premiumBanner}>
              <View style={styles.premiumBannerContent}>
                <IconSymbol name="star.fill" size={24} color={colors.highlight} />
                <View style={styles.premiumBannerText}>
                  <Text style={styles.premiumBannerTitle}>Free Plan</Text>
                  <Text style={styles.premiumBannerSubtitle}>
                    Limited to 1 product
                  </Text>
                </View>
              </View>
              <Pressable style={styles.upgradeButton} onPress={handleUpgradePremium}>
                <Text style={styles.upgradeButtonText}>Upgrade</Text>
              </Pressable>
            </View>
          )}
        </ScrollView>

        {/* Add Button */}
        <View style={styles.footer}>
          <Pressable style={buttonStyles.primary} onPress={handleAddProduct}>
            <IconSymbol name="plus.circle.fill" size={20} color="#fff" />
            <Text style={buttonStyles.buttonText}>Add Medication</Text>
          </Pressable>
        </View>

        <Toast
          visible={toastVisible}
          message={toastMessage}
          type={toastType}
          onHide={() => setToastVisible(false)}
        />

        <PremiumModal
          visible={showPremiumModal}
          onClose={() => setShowPremiumModal(false)}
          onPurchaseSuccess={handlePurchaseSuccess}
        />
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  disclaimer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: 12,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: colors.alert,
  },
  disclaimerText: {
    fontSize: 12,
    color: colors.text,
    marginLeft: 8,
    flex: 1,
  },
  content: {
    flex: 1,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 64,
    paddingHorizontal: 32,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
    marginTop: 16,
  },
  emptyStateText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 8,
    textAlign: 'center',
  },
  productsList: {
    padding: 16,
  },
  productCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  productHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  productIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.background,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  productProtocol: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  productStats: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 4,
  },
  deleteButton: {
    padding: 8,
  },
  premiumBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: colors.card,
    padding: 16,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.highlight,
  },
  premiumBannerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  premiumBannerText: {
    marginLeft: 12,
    flex: 1,
  },
  premiumBannerTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  premiumBannerSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 2,
  },
  upgradeButton: {
    backgroundColor: colors.highlight,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  upgradeButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
  },
  footer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.background,
  },
});
