
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Modal, Pressable, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { colors, buttonStyles } from '@/styles/commonStyles';
import { IconSymbol } from './IconSymbol';
import iapService, { SubscriptionProduct } from '@/services/iapService';

interface PremiumModalProps {
  visible: boolean;
  onClose: () => void;
  onPurchaseSuccess: () => void;
}

export default function PremiumModal({ visible, onClose, onPurchaseSuccess }: PremiumModalProps) {
  const [products, setProducts] = useState<SubscriptionProduct[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingProducts, setLoadingProducts] = useState(true);

  useEffect(() => {
    if (visible) {
      loadProducts();
    }
  }, [visible]);

  const loadProducts = async () => {
    try {
      setLoadingProducts(true);
      const availableProducts = await iapService.getProducts();
      setProducts(availableProducts);
      
      // Pre-select monthly by default
      if (availableProducts.length > 0) {
        const monthly = availableProducts.find(p => p.productId.includes('monthly'));
        setSelectedProduct(monthly?.productId || availableProducts[0].productId);
      }
    } catch (error) {
      console.error('Error loading products:', error);
      Alert.alert('Error', 'Failed to load subscription options. Please try again.');
    } finally {
      setLoadingProducts(false);
    }
  };

  const handlePurchase = async () => {
    if (!selectedProduct) {
      Alert.alert('Error', 'Please select a subscription plan');
      return;
    }

    try {
      setLoading(true);
      const success = await iapService.purchaseSubscription(selectedProduct);
      
      if (success) {
        Alert.alert(
          'Success!',
          'Your subscription is now active. Enjoy unlimited tracking!',
          [
            {
              text: 'OK',
              onPress: () => {
                onPurchaseSuccess();
                onClose();
              },
            },
          ]
        );
      }
    } catch (error: any) {
      console.error('Purchase error:', error);
      Alert.alert(
        'Purchase Failed',
        error.message || 'Unable to complete purchase. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleRestore = async () => {
    try {
      setLoading(true);
      const restored = await iapService.restorePurchases();
      
      if (restored) {
        Alert.alert(
          'Success!',
          'Your subscription has been restored.',
          [
            {
              text: 'OK',
              onPress: () => {
                onPurchaseSuccess();
                onClose();
              },
            },
          ]
        );
      } else {
        Alert.alert(
          'No Purchases Found',
          'We couldn\'t find any previous purchases to restore.'
        );
      }
    } catch (error: any) {
      console.error('Restore error:', error);
      Alert.alert(
        'Restore Failed',
        error.message || 'Unable to restore purchases. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const getProductDisplayName = (product: SubscriptionProduct) => {
    if (product.productId.includes('monthly')) {
      return 'Monthly';
    } else if (product.productId.includes('annual')) {
      return 'Annual';
    }
    return product.title;
  };

  const getProductSavings = (product: SubscriptionProduct) => {
    if (product.productId.includes('annual')) {
      return 'Save 30%';
    }
    return null;
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <Pressable style={styles.closeButton} onPress={onClose} disabled={loading}>
            <IconSymbol name="xmark" size={24} color={colors.textSecondary} />
          </Pressable>

          <View style={styles.header}>
            <IconSymbol name="star.fill" size={64} color={colors.highlight} />
            <Text style={styles.title}>Upgrade to Premium</Text>
            <Text style={styles.subtitle}>Unlock unlimited tracking</Text>
          </View>

          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            <View style={styles.limitBanner}>
              <IconSymbol name="exclamationmark.circle.fill" size={20} color={colors.highlight} />
              <Text style={styles.limitText}>
                Free tier limits 1 medication—upgrade for unlimited.
              </Text>
            </View>

            <View style={styles.feature}>
              <IconSymbol name="checkmark.circle.fill" size={24} color={colors.success} />
              <Text style={styles.featureText}>Unlimited products & protocols</Text>
            </View>

            <View style={styles.feature}>
              <IconSymbol name="checkmark.circle.fill" size={24} color={colors.success} />
              <Text style={styles.featureText}>Advanced inventory tracking</Text>
            </View>

            <View style={styles.feature}>
              <IconSymbol name="checkmark.circle.fill" size={24} color={colors.success} />
              <Text style={styles.featureText}>Dose calendar & reminders</Text>
            </View>

            <View style={styles.feature}>
              <IconSymbol name="checkmark.circle.fill" size={24} color={colors.success} />
              <Text style={styles.featureText}>Export reports (PDF/CSV)</Text>
            </View>

            <View style={styles.feature}>
              <IconSymbol name="checkmark.circle.fill" size={24} color={colors.success} />
              <Text style={styles.featureText}>Priority support</Text>
            </View>

            <Text style={styles.sectionTitle}>Choose Your Plan</Text>

            {loadingProducts ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={colors.primary} />
                <Text style={styles.loadingText}>Loading plans...</Text>
              </View>
            ) : (
              <View style={styles.productsContainer}>
                {products.map((product) => {
                  const isSelected = selectedProduct === product.productId;
                  const savings = getProductSavings(product);
                  
                  return (
                    <Pressable
                      key={product.productId}
                      style={[
                        styles.productCard,
                        isSelected && styles.productCardSelected,
                      ]}
                      onPress={() => setSelectedProduct(product.productId)}
                      disabled={loading}
                    >
                      <View style={styles.productHeader}>
                        <View style={styles.productTitleRow}>
                          <Text style={[styles.productTitle, isSelected && styles.productTitleSelected]}>
                            {getProductDisplayName(product)}
                          </Text>
                          {savings && (
                            <View style={styles.savingsBadge}>
                              <Text style={styles.savingsText}>{savings}</Text>
                            </View>
                          )}
                        </View>
                        <View style={[styles.radioButton, isSelected && styles.radioButtonSelected]}>
                          {isSelected && <View style={styles.radioButtonInner} />}
                        </View>
                      </View>
                      <Text style={[styles.productPrice, isSelected && styles.productPriceSelected]}>
                        {product.localizedPrice}
                        {product.subscriptionPeriod && (
                          <Text style={styles.productPeriod}> / {product.subscriptionPeriod}</Text>
                        )}
                      </Text>
                      {product.productId.includes('annual') && (
                        <Text style={styles.productDetail}>~$2.08/month</Text>
                      )}
                    </Pressable>
                  );
                })}
              </View>
            )}

            <Text style={styles.disclaimer}>
              Cancel anytime. No commitments. Your data stays private and secure.
              {'\n\n'}
              Subscriptions will be charged to your Apple ID account at confirmation of purchase.
              Subscriptions automatically renew unless canceled at least 24 hours before the end of the current period.
            </Text>
          </ScrollView>

          <View style={styles.footer}>
            <Pressable
              style={[buttonStyles.primary, loading && styles.buttonDisabled]}
              onPress={handlePurchase}
              disabled={loading || loadingProducts || !selectedProduct}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={buttonStyles.buttonText}>Subscribe Now</Text>
              )}
            </Pressable>
            
            <Pressable
              style={styles.restoreButton}
              onPress={handleRestore}
              disabled={loading || loadingProducts}
            >
              <Text style={styles.restoreText}>Restore Purchases</Text>
            </Pressable>

            <Pressable style={styles.laterButton} onPress={onClose} disabled={loading}>
              <Text style={styles.laterText}>Maybe Later</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    backgroundColor: colors.background,
    borderRadius: 16,
    width: '90%',
    maxWidth: 400,
    maxHeight: '85%',
    overflow: 'hidden',
  },
  closeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 10,
    padding: 8,
  },
  header: {
    alignItems: 'center',
    paddingTop: 32,
    paddingHorizontal: 24,
    paddingBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
    marginTop: 16,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 4,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  limitBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
    borderLeftWidth: 3,
    borderLeftColor: colors.highlight,
  },
  limitText: {
    fontSize: 14,
    color: colors.text,
    marginLeft: 8,
    flex: 1,
    lineHeight: 20,
    fontWeight: '500',
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  featureText: {
    fontSize: 16,
    color: colors.text,
    marginLeft: 12,
    flex: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: 24,
    marginBottom: 16,
  },
  loadingContainer: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  loadingText: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 12,
  },
  productsContainer: {
    gap: 12,
    marginBottom: 24,
  },
  productCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: colors.border,
  },
  productCardSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.card,
  },
  productHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  productTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  productTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
  },
  productTitleSelected: {
    color: colors.primary,
  },
  savingsBadge: {
    backgroundColor: colors.success,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  savingsText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#fff',
  },
  radioButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioButtonSelected: {
    borderColor: colors.primary,
  },
  radioButtonInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: colors.primary,
  },
  productPrice: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
  },
  productPriceSelected: {
    color: colors.primary,
  },
  productPeriod: {
    fontSize: 16,
    fontWeight: '400',
    color: colors.textSecondary,
  },
  productDetail: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 4,
  },
  disclaimer: {
    fontSize: 11,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 16,
    marginBottom: 16,
  },
  footer: {
    padding: 24,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  restoreButton: {
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 12,
  },
  restoreText: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: '600',
  },
  laterButton: {
    paddingVertical: 12,
    alignItems: 'center',
    marginTop: 8,
  },
  laterText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
});
