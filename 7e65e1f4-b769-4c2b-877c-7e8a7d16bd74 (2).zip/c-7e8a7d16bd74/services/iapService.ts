
import { Platform, AppState, AppStateStatus } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Lazy load react-native-iap to avoid early native module access
let RNIap: any = null;

const loadRNIap = async () => {
  if (!RNIap) {
    try {
      RNIap = await import('react-native-iap');
      console.log('react-native-iap loaded successfully');
    } catch (error) {
      console.error('Failed to load react-native-iap:', error);
      throw error;
    }
  }
  return RNIap;
};

// Product IDs for subscriptions - using the actual product IDs from App Store Connect
export const SUBSCRIPTION_IDS = Platform.select({
  ios: [
    'com.chiptspb.biohackernexus.premium.monthly',
    'com.chiptspb.biohackernexus.premium.annual'
  ],
  android: [
    'com.chiptspb.biohackernexus.premium.monthly',
    'com.chiptspb.biohackernexus.premium.annual'
  ],
  default: [
    'com.chiptspb.biohackernexus.premium.monthly',
    'com.chiptspb.biohackernexus.premium.annual'
  ],
}) as string[];

const SUBSCRIPTION_CACHE_KEY = '@biohacker_subscription_status';
const SUBSCRIPTION_CACHE_TIMESTAMP_KEY = '@biohacker_subscription_timestamp';
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export interface SubscriptionProduct {
  productId: string;
  title: string;
  description: string;
  price: string;
  localizedPrice: string;
  currency: string;
  subscriptionPeriod?: string;
}

class IAPService {
  private isInitialized = false;
  private purchaseUpdateSubscription: any = null;
  private purchaseErrorSubscription: any = null;
  private appStateSubscription: any = null;
  private cachedSubscriptionStatus: boolean | null = null;
  private lastCheckTimestamp: number = 0;

  async initialize(): Promise<void> {
    if (this.isInitialized) {
      console.log('IAP already initialized');
      return;
    }

    try {
      console.log('Loading react-native-iap module...');
      const iap = await loadRNIap();
      
      console.log('Initializing IAP connection...');
      await iap.initConnection();
      console.log('IAP connection initialized successfully');
      
      // Clear any pending transactions on iOS
      if (Platform.OS === 'ios') {
        await iap.clearTransactionIOS();
        console.log('Cleared pending iOS transactions');
      }

      // Flush failed purchases on Android
      if (Platform.OS === 'android') {
        await iap.flushFailedPurchasesCachedAsPendingAndroid();
        console.log('Flushed failed Android purchases');
      }

      this.isInitialized = true;

      // Setup app state listener to check subscription when app comes to foreground
      this.setupAppStateListener();
    } catch (error) {
      console.error('Error initializing IAP:', error);
      throw error;
    }
  }

  private setupAppStateListener(): void {
    this.appStateSubscription = AppState.addEventListener('change', (nextAppState: AppStateStatus) => {
      if (nextAppState === 'active') {
        console.log('App came to foreground, checking subscription status...');
        this.checkSubscriptionStatus(true).catch(error => {
          console.error('Error checking subscription on foreground:', error);
        });
      }
    });
  }

  async getProducts(): Promise<SubscriptionProduct[]> {
    try {
      if (!this.isInitialized) {
        await this.initialize();
      }

      const iap = await loadRNIap();

      console.log('Fetching subscription products:', SUBSCRIPTION_IDS);
      const products = await iap.getSubscriptions({ skus: SUBSCRIPTION_IDS });
      console.log('Fetched products:', products);

      return products.map((product: any) => {
        // Extract subscription period for display
        let subscriptionPeriod = '';
        if (product.productId.includes('monthly')) {
          subscriptionPeriod = 'month';
        } else if (product.productId.includes('annual')) {
          subscriptionPeriod = 'year';
        }

        return {
          productId: product.productId,
          title: product.title || 'Premium Subscription',
          description: product.description || '',
          price: product.price || '0',
          localizedPrice: product.localizedPrice || '$0.00',
          currency: product.currency || 'USD',
          subscriptionPeriod,
        };
      });
    } catch (error) {
      console.error('Error fetching products:', error);
      // Return mock products for development/testing if fetch fails
      return [
        {
          productId: 'com.chiptspb.biohackernexus.premium.monthly',
          title: 'Premium Monthly',
          description: 'Unlimited tracking',
          price: '2.99',
          localizedPrice: '$2.99',
          currency: 'USD',
          subscriptionPeriod: 'month',
        },
        {
          productId: 'com.chiptspb.biohackernexus.premium.annual',
          title: 'Premium Annual',
          description: 'Best value - Save 30%',
          price: '24.99',
          localizedPrice: '$24.99',
          currency: 'USD',
          subscriptionPeriod: 'year',
        },
      ];
    }
  }

  async purchaseSubscription(productId: string): Promise<boolean> {
    try {
      if (!this.isInitialized) {
        await this.initialize();
      }

      const iap = await loadRNIap();

      console.log('Requesting purchase for:', productId);
      
      const purchase = await iap.requestSubscription({
        sku: productId,
        ...(Platform.OS === 'android' && {
          subscriptionOffers: [
            {
              sku: productId,
              offerToken: '',
            },
          ],
        }),
      });

      console.log('Purchase successful:', purchase);

      // Finish the transaction
      if (Platform.OS === 'ios') {
        await iap.finishTransaction({ purchase, isConsumable: false });
      } else if (Platform.OS === 'android') {
        await iap.acknowledgePurchaseAndroid({ token: purchase.purchaseToken || '' });
      }

      // Clear cache and update status
      await this.clearSubscriptionCache();
      await this.checkSubscriptionStatus(true);

      return true;
    } catch (error: any) {
      console.error('Purchase error:', error);
      
      // User cancelled
      if (error.code === 'E_USER_CANCELLED') {
        console.log('User cancelled purchase');
        return false;
      }

      throw error;
    }
  }

  async restorePurchases(): Promise<boolean> {
    try {
      if (!this.isInitialized) {
        await this.initialize();
      }

      const iap = await loadRNIap();

      console.log('Restoring purchases...');
      const purchases = await iap.getAvailablePurchases();
      console.log('Available purchases:', purchases);

      if (purchases && purchases.length > 0) {
        // Check if any of the purchases are for our subscription products
        const validSubscriptions = purchases.filter((purchase: any) =>
          SUBSCRIPTION_IDS.includes(purchase.productId)
        );

        if (validSubscriptions.length > 0) {
          console.log('Valid subscriptions found:', validSubscriptions.length);
          
          // Finish any unfinished transactions
          for (const purchase of validSubscriptions) {
            try {
              if (Platform.OS === 'ios') {
                await iap.finishTransaction({ purchase, isConsumable: false });
              } else if (Platform.OS === 'android' && purchase.purchaseToken) {
                await iap.acknowledgePurchaseAndroid({ token: purchase.purchaseToken });
              }
            } catch (error) {
              console.error('Error finishing transaction:', error);
            }
          }
          
          // Clear cache and update status
          await this.clearSubscriptionCache();
          await this.checkSubscriptionStatus(true);
          
          return true;
        }
      }

      console.log('No valid subscriptions found');
      return false;
    } catch (error) {
      console.error('Error restoring purchases:', error);
      throw error;
    }
  }

  async checkSubscriptionStatus(forceRefresh: boolean = false): Promise<boolean> {
    try {
      const now = Date.now();

      // Return cached status if available and not expired (unless force refresh)
      if (!forceRefresh && this.cachedSubscriptionStatus !== null && 
          (now - this.lastCheckTimestamp) < CACHE_DURATION) {
        console.log('Returning cached subscription status:', this.cachedSubscriptionStatus);
        return this.cachedSubscriptionStatus;
      }

      // Try to get from AsyncStorage cache first
      if (!forceRefresh) {
        const cachedStatus = await this.getCachedSubscriptionStatus();
        if (cachedStatus !== null) {
          this.cachedSubscriptionStatus = cachedStatus;
          this.lastCheckTimestamp = now;
          return cachedStatus;
        }
      }

      if (!this.isInitialized) {
        await this.initialize();
      }

      const iap = await loadRNIap();

      console.log('Checking subscription status with StoreKit...');
      
      // For iOS, use Transaction.currentEntitlements (StoreKit 2)
      if (Platform.OS === 'ios') {
        try {
          // Get current entitlements using StoreKit 2
          const purchases = await iap.getAvailablePurchases();
          
          if (purchases && purchases.length > 0) {
            const hasValidSubscription = purchases.some((purchase: any) => {
              const isOurProduct = SUBSCRIPTION_IDS.includes(purchase.productId);
              console.log('Checking purchase:', purchase.productId, 'isOurProduct:', isOurProduct);
              return isOurProduct;
            });
            
            console.log('Subscription status:', hasValidSubscription);
            
            // Cache the result
            this.cachedSubscriptionStatus = hasValidSubscription;
            this.lastCheckTimestamp = now;
            await this.cacheSubscriptionStatus(hasValidSubscription);
            
            return hasValidSubscription;
          }
        } catch (error) {
          console.error('Error checking iOS entitlements:', error);
        }
      } else if (Platform.OS === 'android') {
        // For Android, check available purchases
        const purchases = await iap.getAvailablePurchases();
        
        if (purchases && purchases.length > 0) {
          const hasValidSubscription = purchases.some((purchase: any) =>
            SUBSCRIPTION_IDS.includes(purchase.productId)
          );
          
          console.log('Subscription status:', hasValidSubscription);
          
          // Cache the result
          this.cachedSubscriptionStatus = hasValidSubscription;
          this.lastCheckTimestamp = now;
          await this.cacheSubscriptionStatus(hasValidSubscription);
          
          return hasValidSubscription;
        }
      }

      // No valid subscription found
      this.cachedSubscriptionStatus = false;
      this.lastCheckTimestamp = now;
      await this.cacheSubscriptionStatus(false);
      
      return false;
    } catch (error) {
      console.error('Error checking subscription status:', error);
      
      // Return cached status if available on error
      if (this.cachedSubscriptionStatus !== null) {
        return this.cachedSubscriptionStatus;
      }
      
      return false;
    }
  }

  private async cacheSubscriptionStatus(status: boolean): Promise<void> {
    try {
      await AsyncStorage.setItem(SUBSCRIPTION_CACHE_KEY, JSON.stringify(status));
      await AsyncStorage.setItem(SUBSCRIPTION_CACHE_TIMESTAMP_KEY, Date.now().toString());
      console.log('Cached subscription status:', status);
    } catch (error) {
      console.error('Error caching subscription status:', error);
    }
  }

  private async getCachedSubscriptionStatus(): Promise<boolean | null> {
    try {
      const cachedStatus = await AsyncStorage.getItem(SUBSCRIPTION_CACHE_KEY);
      const cachedTimestamp = await AsyncStorage.getItem(SUBSCRIPTION_CACHE_TIMESTAMP_KEY);
      
      if (cachedStatus && cachedTimestamp) {
        const timestamp = parseInt(cachedTimestamp, 10);
        const now = Date.now();
        
        // Check if cache is still valid
        if ((now - timestamp) < CACHE_DURATION) {
          const status = JSON.parse(cachedStatus);
          console.log('Using cached subscription status:', status);
          return status;
        }
      }
      
      return null;
    } catch (error) {
      console.error('Error getting cached subscription status:', error);
      return null;
    }
  }

  private async clearSubscriptionCache(): Promise<void> {
    try {
      await AsyncStorage.multiRemove([SUBSCRIPTION_CACHE_KEY, SUBSCRIPTION_CACHE_TIMESTAMP_KEY]);
      this.cachedSubscriptionStatus = null;
      this.lastCheckTimestamp = 0;
      console.log('Cleared subscription cache');
    } catch (error) {
      console.error('Error clearing subscription cache:', error);
    }
  }

  setupPurchaseListeners(
    onPurchaseSuccess: () => void,
    onPurchaseError: (error: any) => void
  ): void {
    loadRNIap().then((iap) => {
      // Remove existing listeners
      if (this.purchaseUpdateSubscription) {
        this.purchaseUpdateSubscription.remove();
      }
      if (this.purchaseErrorSubscription) {
        this.purchaseErrorSubscription.remove();
      }

      // Purchase update listener
      this.purchaseUpdateSubscription = iap.purchaseUpdatedListener(
        async (purchase: any) => {
          console.log('Purchase updated:', purchase);
          const receipt = purchase.transactionReceipt;

          if (receipt) {
            try {
              // Finish the transaction
              if (Platform.OS === 'ios') {
                await iap.finishTransaction({ purchase, isConsumable: false });
              } else if (Platform.OS === 'android') {
                await iap.acknowledgePurchaseAndroid({ token: purchase.purchaseToken || '' });
              }

              // Clear cache and update status
              await this.clearSubscriptionCache();
              await this.checkSubscriptionStatus(true);

              onPurchaseSuccess();
            } catch (error) {
              console.error('Error finishing transaction:', error);
            }
          }
        }
      );

      // Purchase error listener
      this.purchaseErrorSubscription = iap.purchaseErrorListener((error: any) => {
        console.log('Purchase error listener:', error);
        if (error.code !== 'E_USER_CANCELLED') {
          onPurchaseError(error);
        }
      });
    }).catch((error) => {
      console.error('Failed to setup purchase listeners:', error);
    });
  }

  removePurchaseListeners(): void {
    if (this.purchaseUpdateSubscription) {
      this.purchaseUpdateSubscription.remove();
      this.purchaseUpdateSubscription = null;
    }
    if (this.purchaseErrorSubscription) {
      this.purchaseErrorSubscription.remove();
      this.purchaseErrorSubscription = null;
    }
    if (this.appStateSubscription) {
      this.appStateSubscription.remove();
      this.appStateSubscription = null;
    }
  }

  async endConnection(): Promise<void> {
    try {
      this.removePurchaseListeners();
      
      if (RNIap) {
        await RNIap.endConnection();
      }
      
      this.isInitialized = false;
      console.log('IAP connection ended');
    } catch (error) {
      console.error('Error ending IAP connection:', error);
    }
  }
}

export default new IAPService();
